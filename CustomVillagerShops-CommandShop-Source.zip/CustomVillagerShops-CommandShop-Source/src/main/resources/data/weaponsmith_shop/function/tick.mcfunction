# Clear the marker if the villager changes profession.
execute as @e[type=minecraft:villager,tag=weaponsmith_shop_ready,nbt=!{VillagerData:{profession:"minecraft:weaponsmith"}}] run tag @s remove weaponsmith_shop_ready
# Apply shop to newly employed or unmarked villagers.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:weaponsmith"}},tag=!weaponsmith_shop_ready] run function weaponsmith_shop:setup_shop
