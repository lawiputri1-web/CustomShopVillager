# Apply this shop to existing weaponsmith villagers when the world loads.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:weaponsmith"}},tag=!weaponsmith_shop_ready] run function weaponsmith_shop:setup_shop
