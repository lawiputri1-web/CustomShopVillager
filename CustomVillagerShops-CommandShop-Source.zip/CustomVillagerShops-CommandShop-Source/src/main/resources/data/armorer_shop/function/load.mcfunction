# Apply this shop to existing armorer villagers when the world loads.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:armorer"}},tag=!armorer_shop_ready] run function armorer_shop:setup_shop
