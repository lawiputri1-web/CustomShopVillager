# Clear the marker if the villager changes profession.
execute as @e[type=minecraft:villager,tag=armorer_shop_ready,nbt=!{VillagerData:{profession:"minecraft:armorer"}}] run tag @s remove armorer_shop_ready
# Apply shop to newly employed or unmarked villagers.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:armorer"}},tag=!armorer_shop_ready] run function armorer_shop:setup_shop
