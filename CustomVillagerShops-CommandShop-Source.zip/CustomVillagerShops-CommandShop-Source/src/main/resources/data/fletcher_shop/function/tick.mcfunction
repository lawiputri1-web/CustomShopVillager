# Clear the marker if the villager changes profession.
execute as @e[type=minecraft:villager,tag=fletcher_shop_ready,nbt=!{VillagerData:{profession:"minecraft:fletcher"}}] run tag @s remove fletcher_shop_ready
# Apply shop to newly employed or unmarked villagers.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:fletcher"}},tag=!fletcher_shop_ready] run function fletcher_shop:setup_shop
