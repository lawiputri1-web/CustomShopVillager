# Apply this shop to existing fletcher villagers when the world loads.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:fletcher"}},tag=!fletcher_shop_ready] run function fletcher_shop:setup_shop
