# Apply this shop to existing librarian villagers when the world loads.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:librarian"}},tag=!librarian_shop_ready] run function librarian_shop:setup_shop
