# Clear the marker if the villager changes profession.
execute as @e[type=minecraft:villager,tag=librarian_shop_ready,nbt=!{VillagerData:{profession:"minecraft:librarian"}}] run tag @s remove librarian_shop_ready
# Apply shop to newly employed or unmarked villagers.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:librarian"}},tag=!librarian_shop_ready] run function librarian_shop:setup_shop
