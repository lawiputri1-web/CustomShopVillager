# Clear the marker if the villager changes profession.
execute as @e[type=minecraft:villager,tag=butcher_shop_ready,nbt=!{VillagerData:{profession:"minecraft:butcher"}}] run tag @s remove butcher_shop_ready
# Apply shop to newly employed or unmarked butcher villagers.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:butcher"}},tag=!butcher_shop_ready] run function butcher_shop:setup_shop
