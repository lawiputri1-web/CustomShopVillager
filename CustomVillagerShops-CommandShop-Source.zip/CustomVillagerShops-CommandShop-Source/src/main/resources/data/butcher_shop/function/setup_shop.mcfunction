# Butcher shop (Smoker workstation): cooked meat and cooked fish for 1 emerald each; vanilla villager appearance preserved.

data modify entity @s Offers.Recipes set value []
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:cooked_beef",count:64},uses:0,maxUses:2147483647,xp:0,specialPrice:0,demand:0,priceMultiplier:0.0f}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:cooked_porkchop",count:64},uses:0,maxUses:2147483647,xp:0,specialPrice:0,demand:0,priceMultiplier:0.0f}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:cooked_chicken",count:64},uses:0,maxUses:2147483647,xp:0,specialPrice:0,demand:0,priceMultiplier:0.0f}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:cooked_mutton",count:64},uses:0,maxUses:2147483647,xp:0,specialPrice:0,demand:0,priceMultiplier:0.0f}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:cooked_rabbit",count:64},uses:0,maxUses:2147483647,xp:0,specialPrice:0,demand:0,priceMultiplier:0.0f}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:cooked_cod",count:64},uses:0,maxUses:2147483647,xp:0,specialPrice:0,demand:0,priceMultiplier:0.0f}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:cooked_salmon",count:16},uses:0,maxUses:2147483647,xp:0,specialPrice:0,demand:0,priceMultiplier:0.0f}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:rabbit_stew",count:16},uses:0,maxUses:2147483647,xp:0,specialPrice:0,demand:0,priceMultiplier:0.0f}
tag @s add butcher_shop_ready
