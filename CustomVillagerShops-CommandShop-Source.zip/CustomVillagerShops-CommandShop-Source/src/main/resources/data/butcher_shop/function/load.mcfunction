# Apply this shop to existing butcher villagers when the world loads. The butcher profession uses a smoker as its job-site block.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:butcher"}},tag=!butcher_shop_ready] run function butcher_shop:setup_shop
