# Clear the marker if the villager changes profession.
execute as @e[type=minecraft:villager,tag=toolsmith_shop_ready,nbt=!{VillagerData:{profession:"minecraft:toolsmith"}}] run tag @s remove toolsmith_shop_ready
# Apply shop to newly employed or unmarked villagers.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:toolsmith"}},tag=!toolsmith_shop_ready] run function toolsmith_shop:setup_shop
