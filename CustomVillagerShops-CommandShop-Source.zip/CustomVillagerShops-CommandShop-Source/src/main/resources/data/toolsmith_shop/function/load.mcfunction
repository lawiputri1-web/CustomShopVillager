# Apply this shop to existing toolsmith villagers when the world loads.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:toolsmith"}},tag=!toolsmith_shop_ready] run function toolsmith_shop:setup_shop
