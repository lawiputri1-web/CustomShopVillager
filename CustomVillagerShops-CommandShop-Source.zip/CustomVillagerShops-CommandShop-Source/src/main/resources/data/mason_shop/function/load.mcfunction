# Apply this shop to existing mason villagers when the world loads.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:mason"}},tag=!mason_shop_ready] run function mason_shop:setup_shop
