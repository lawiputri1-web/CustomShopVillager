# Clear the marker if the villager changes profession.
execute as @e[type=minecraft:villager,tag=mason_shop_ready,nbt=!{VillagerData:{profession:"minecraft:mason"}}] run tag @s remove mason_shop_ready
# Apply shop to newly employed or unmarked villagers.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:mason"}},tag=!mason_shop_ready] run function mason_shop:setup_shop
