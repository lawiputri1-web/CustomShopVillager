# Apply this shop to existing shepherd villagers when the world loads.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:shepherd"}},tag=!shepherd_shop_ready] run function shepherd_shop:setup_shop
