# Clear the marker if the villager changes profession.
execute as @e[type=minecraft:villager,tag=shepherd_shop_ready,nbt=!{VillagerData:{profession:"minecraft:shepherd"}}] run tag @s remove shepherd_shop_ready
# Apply shop to newly employed or unmarked villagers.
execute as @e[type=minecraft:villager,nbt={VillagerData:{profession:"minecraft:shepherd"}},tag=!shepherd_shop_ready] run function shepherd_shop:setup_shop
