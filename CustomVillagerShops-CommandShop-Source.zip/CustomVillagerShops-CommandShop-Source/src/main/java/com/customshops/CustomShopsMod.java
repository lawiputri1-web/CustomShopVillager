package com.customshops;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.village.VillagerData;
import net.minecraft.village.VillagerProfession;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.entity.Entity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.OptionalInt;

import static net.minecraft.server.command.CommandManager.literal;

public final class CustomShopsMod implements ModInitializer {
    public static final String MOD_ID = "armorer_fletcher_piglin_op";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static final String TEMP_TAG = "customshops_command_temp";

    private record Shop(String id, String title, RegistryKey<VillagerProfession> profession, String function) {}

    private static final List<Shop> SHOPS = List.of(
        new Shop("armorer", "Armorer", VillagerProfession.ARMORER, "armorer_shop:setup_shop"),
        new Shop("butcher", "Butcher", VillagerProfession.BUTCHER, "butcher_shop:setup_shop"),
        new Shop("fletcher", "Fletcher", VillagerProfession.FLETCHER, "fletcher_shop:setup_shop"),
        new Shop("librarian", "Librarian", VillagerProfession.LIBRARIAN, "librarian_shop:setup_shop"),
        new Shop("mason", "Mason", VillagerProfession.MASON, "mason_shop:setup_shop"),
        new Shop("shepherd", "Shepherd", VillagerProfession.SHEPHERD, "shepherd_shop:setup_shop"),
        new Shop("toolsmith", "Toolsmith", VillagerProfession.TOOLSMITH, "toolsmith_shop:setup_shop"),
        new Shop("weaponsmith", "Weaponsmith", VillagerProfession.WEAPONSMITH, "weaponsmith_shop:setup_shop")
    );

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            var root = literal("shop")
                .executes(context -> {
                    ServerPlayerEntity player = context.getSource().getPlayerOrException();
                    showMenu(player);
                    return 1;
                });
            for (Shop shop : SHOPS) {
                root.then(literal(shop.id()).executes(context -> {
                    ServerPlayerEntity player = context.getSource().getPlayerOrException();
                    openShop(context.getSource(), player, shop);
                    return 1;
                }));
            }
            dispatcher.register(root);
        });

        ServerTickEvents.END_SERVER_TICK.register(CustomShopsMod::cleanupTemporaryVillagers);
        LOGGER.info("Custom Villager Shops command shop loaded. Use /shop.");
    }

    private static void showMenu(ServerPlayerEntity player) {
        player.sendMessage(Text.literal("========== VILLAGER SHOP ==========").formatted(Formatting.GOLD, Formatting.BOLD), false);
        MutableText line = Text.empty();
        for (int i = 0; i < SHOPS.size(); i++) {
            Shop shop = SHOPS.get(i);
            line.append(Text.literal("[" + shop.title() + "]")
                .styled(style -> style.withColor(Formatting.GREEN)
                    .withClickEvent(new ClickEvent.RunCommand("/shop " + shop.id()))));
            if (i < SHOPS.size() - 1) line.append(Text.literal("  "));
            if (i == 3) {
                player.sendMessage(line, false);
                line = Text.empty();
            }
        }
        if (!line.getString().isEmpty()) player.sendMessage(line, false);
        player.sendMessage(Text.literal("Klik nama profesi di chat untuk membuka trade. Tidak perlu spawn villager manual.").formatted(Formatting.GRAY), false);
    }

    private static void openShop(ServerCommandSource source, ServerPlayerEntity player, Shop shop) {
        if (!(player.getWorld() instanceof ServerWorld world)) return;
        VillagerEntity villager = EntityType.VILLAGER.create(world, SpawnReason.COMMAND);
        if (villager == null) {
            player.sendMessage(Text.literal("Gagal menyiapkan shop sementara.").formatted(Formatting.RED), false);
            return;
        }

        villager.refreshPositionAndAngles(player.getX(), player.getY(), player.getZ(), player.getYaw(), 0.0F);
        villager.addCommandTag(TEMP_TAG);
        villager.setAiDisabled(true);
        villager.setSilent(true);
        villager.setInvulnerable(true);
        villager.setNoGravity(true);
        var professionEntry = Registries.VILLAGER_PROFESSION.getEntry(shop.profession()).orElseThrow();
        VillagerData data = villager.getVillagerData().withProfession(professionEntry).withLevel(5);
        villager.setVillagerData(data);

        if (!world.spawnEntity(villager)) {
            player.sendMessage(Text.literal("Gagal menyiapkan villager shop sementara.").formatted(Formatting.RED), false);
            return;
        }

        try {
            MinecraftServer server = world.getServer();
            ServerCommandSource functionSource = server.getCommandSource()
                .withWorld(world)
                .withEntity(villager)
                .withPosition(villager.getPos())
                .withLevel(2);
            server.getCommandManager().executeWithPrefix(functionSource, "function " + shop.function());

            villager.setCustomer(player);
            OptionalInt syncId = player.openHandledScreen(villager);
            if (syncId.isEmpty()) {
                villager.setCustomer(null);
                villager.discard();
                player.sendMessage(Text.literal("Layar trade gagal dibuka. Coba lagi.").formatted(Formatting.RED), false);
                return;
            }
            villager.sendOffers(player, Text.literal(shop.title() + " Shop"), 5);
            player.sendMessage(Text.literal("Membuka trade: " + shop.title()).formatted(Formatting.GREEN), false);
        } catch (Exception exception) {
            villager.setCustomer(null);
            villager.discard();
            LOGGER.error("Could not open temporary shop for profession {}", shop.id(), exception);
            player.sendMessage(Text.literal("Shop gagal dibuka. Periksa latest.log.").formatted(Formatting.RED), false);
        }
    }

    private static void cleanupTemporaryVillagers(MinecraftServer server) {
        for (ServerWorld world : server.getWorlds()) {
            for (Entity entity : world.iterateEntities()) {
                if (entity instanceof VillagerEntity villager && villager.getCommandTags().contains(TEMP_TAG)) {
                    if (villager.getCustomer() == null || villager.getCustomer().isRemoved()) {
                        villager.discard();
                    }
                }
            }
        }
    }
}
